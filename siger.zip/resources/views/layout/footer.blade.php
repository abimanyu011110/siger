<div class="footer">
	<div class="footer-inner">
		<div class="footer-content">
			<span class="bigger-120">
				<span class="blue bolder">BPKP</span>
				Perwakilan Provinsi Lampung &copy; 2017
			</span>
		</div>
	</div>
</div>